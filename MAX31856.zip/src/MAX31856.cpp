
#include <Arduino.h>
#include "MAX31856.h"

// Manual for library: http://lygte-info.dk/project/MAX31856Library%20UK.html
// This is version 1.01 from 2020-5-23
// By HKJ from lygte-info.dk


//----------------------------------------------------------------------------------------------------
// Read a single register
byte MAX31856::readReg(byte reg) {
  reg &= 0x7F; // This is a read address
  digitalWrite(sckPin, HIGH);
  digitalWrite(csPin, LOW);
  spiXfer(reg);
  byte u = spiXfer(0xFF);
  digitalWrite(csPin, HIGH);
  return u;
}

//----------------------------------------------------------------------------------------------------
// Read two register in sequence
int16_t MAX31856::readReg2(byte reg) {
  reg &= 0x7F; // This is a read address
  digitalWrite(sckPin, HIGH);
  digitalWrite(csPin, LOW);
  spiXfer(reg);
  int16_t u = spiXfer(0xFF) << 8 | spiXfer(0xFF);
  digitalWrite(csPin, HIGH);
  return u;
}

//----------------------------------------------------------------------------------------------------
// Read 3 register in sequence, used for temperature
int32_t MAX31856::readReg3(byte reg) {
  reg &= 0x7F; // This is a read address
  digitalWrite(sckPin, HIGH);
  digitalWrite(csPin, LOW);
  spiXfer(reg);
  int32_t u = ((((uint32_t) spiXfer(0xFF) << 8) | spiXfer(0xFF)) << 8) | spiXfer(0xFF);
  digitalWrite(csPin, HIGH);
  if (u & 0x800000) u |= 0xff000000;  // Fix sign
  return u;

}

//----------------------------------------------------------------------------------------------------
// Write a single register
// It is possible to write multiple registers, but I did not see any reason to add it.
void MAX31856::writeReg(byte reg, byte val) {
  reg |= 0x80; // Write address
  digitalWrite(sckPin, HIGH);
  digitalWrite(csPin, LOW);
  spiXfer(reg);
  spiXfer(val);
  digitalWrite(csPin, HIGH);
}

//----------------------------------------------------------------------------------------------------
// Transmit a byte and receive a byte at the same time.
byte MAX31856::spiXfer(byte v) {
  byte u = 0;
  for (int8_t i = 7; i >= 0; i--) {
    digitalWrite(sckPin, LOW);
    digitalWrite(sdiPin, v & (1 << i));
    digitalWrite(sckPin, HIGH);
    u <<= 1;  // This line adds some delay between write and read
    if (digitalRead(sdoPin)) {
      u |= 1;
    }
  }
  return u;
}

//----------------------------------------------------------------------------------------------------
MAX31856::MAX31856(byte sdiPin, byte sdoPin, byte sckPin, byte csPin) {
  this->sdiPin = sdiPin;
  this->sdoPin = sdoPin;
  this->sckPin = sckPin;
  this->csPin = csPin;
  this->drdyPin = 255;
}

//----------------------------------------------------------------------------------------------------
MAX31856::MAX31856(byte sdiPin, byte sdoPin, byte sckPin, byte csPin, byte drdyPin) {
  this->sdiPin = sdiPin;
  this->sdoPin = sdoPin;
  this->sckPin = sckPin;
  this->csPin = csPin;
  this->drdyPin = drdyPin;
}

//----------------------------------------------------------------------------------------------------
void MAX31856::begin() {
  pinMode(csPin, OUTPUT);
  digitalWrite(csPin, HIGH);
  pinMode(sckPin, OUTPUT);
  digitalWrite(sckPin, LOW);
  pinMode(sdiPin, OUTPUT);
  writeReg0( 0x31);    // Check open sensor with slow timing and use 50Hz rejection
  writeReg1( 0x03);    // 1 sample, type K
  avg = 1;
  writeReg(2, 0x00);    // Report all faults
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setTCType(MaxTCType type) {
  writeReg1( (reg1 & 0xf0) | ((byte) type));
  switch (type) {
    case TC_G8 : voltMultiplicationFactor = 8; break;
    case TC_G32 : voltMultiplicationFactor = 32; break;
    default : voltMultiplicationFactor = 0; break;
  }
}

//----------------------------------------------------------------------------------------------------
MaxTCType MAX31856::getTCType() {
  return (MaxTCType) (reg1 & 0x0f);
}

//----------------------------------------------------------------------------------------------------
byte MAX31856::getFault() {
  byte f = readReg(15);
  if (isVoltMode()) f &= TC_FAULT_VOLT | TC_FAULT_OPEN;
  return f;
}

//----------------------------------------------------------------------------------------------------
// Measured timing (This do not match the datasheet)
// Samples  -> on-demand  auto
// 1 -> 283ms 98ms auto mode sometimes needs an extra 113ms
// 2 -> 323ms 117ms
// 4 -> 403ms 157ms
// 8 -> 563ms 237ms
// 16 -> 882ms 397ms
// First sample takes 283ms, use 300 to get a safety margin
// Each additional sample adds 40ms
uint16_t MAX31856::sampleTime() {
  return 300 - 40 + avg * 40;
}

//----------------------------------------------------------------------------------------------------
void MAX31856::start() {
  writeReg0((reg0 & 0x3f) | 0x40);
  if (drdyPin == 255) {
    doneTime = millis() + sampleTime();
  }
}

//----------------------------------------------------------------------------------------------------
boolean MAX31856::isReady() {
  if (drdyPin == 255) return isRunMode()|| (millis() > doneTime);
  else return digitalRead(drdyPin) == LOW;
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setAuto() {
  writeReg0( reg0 | 0x80);
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setMainsFreq60Hz(boolean yes) {
  writeReg0( reg0 & 0x3f); // Disable auto mode
  writeReg0( (reg0 & 0xfe) | (yes ? 0 : 1));
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setSamples(byte n) {
  if (n > 4) n = 4;
  writeReg1( (reg1 & 0x0f) | n << 4);
  avg = 1 << n;
}

//----------------------------------------------------------------------------------------------------
byte MAX31856::getSamples() {
  return (reg1 >> 4) & 0x07;
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setCJOffset(float ofs) {
  writeReg(9, (int8_t) (ofs * 16));
}

//----------------------------------------------------------------------------------------------------
float MAX31856::getCJOffset() {
  return ((int8_t)readReg(9)) / 16.0;
}

//----------------------------------------------------------------------------------------------------
float MAX31856::readTCTemp() {
  while (!isReady());
  if (isVoltMode()) return readReg3(12) * 1e3 / voltMultiplicationFactor / 1.6 / 4194304.0;  // Result in mV
  return readReg3(12) / 4096.0;
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setCJTemp(float temp) {
  setCJAuto(false);
  int16_t t = temp * 256;
  writeReg(10, t >> 8);
  writeReg(11, t);
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setTCRange(float low, float high) {
  int16_t l = (int16_t)(low * 16);
  int16_t h = (int16_t)(high * 16);
  writeReg(5, h >> 8);
  writeReg(6, h);
  writeReg(7, l >> 8);
  writeReg(8, l);
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setCJAuto(boolean yes) {
  writeReg0( (reg0 & 0xf7) | (yes ? 0 : 0x08));
}

//----------------------------------------------------------------------------------------------------
boolean MAX31856::isCJAuto() {
  return (reg0 & 0x08) == 0;
}
//----------------------------------------------------------------------------------------------------
void MAX31856::setCJRange(int8_t low, int8_t high) {
  writeReg(3, (byte) high);
  writeReg(4, (byte) low);
}

//----------------------------------------------------------------------------------------------------
float MAX31856::readCJTemp() {
  return readReg2(10) / 256.0;
}

//----------------------------------------------------------------------------------------------------
void MAX31856::setFaultMask(byte mask) {
  writeReg(2, mask & 0x3f);
}

//----------------------------------------------------------------------------------------------------
void MAX31856::serialPrintAllRegisters() {
  Serial.print("0x00: Config 0:       0b"); Serial.println(readReg(0), 2);
  Serial.print("0x01: Config 1:       0b"); Serial.println(readReg(1), 2);
  Serial.print("0x02: Fault mask:     0b"); Serial.println(readReg(2), 2);
  Serial.print("0x03: CJ high fault:  "); Serial.println(readCJRangeHigh());
  Serial.print("0x04: CJ low fault:   "); Serial.println(readCJRangeLow());
  Serial.print("0x05+: TJ high fault: "); Serial.println(readTCRangeHigh());
  Serial.print("0x07+: TJ low fault:  "); Serial.println(readTCRangeLow());
  Serial.print("0x09: CJ offset:      "); Serial.println(getCJOffset());
  Serial.print("0x0a+: CJ temp:       "); Serial.println(readCJTemp());
  Serial.print("0x0c+: TJ temp:       "); Serial.println(readTCTemp());
  Serial.print("0x0f: Faults:         0b"); Serial.println(readReg(15), 2);
}
