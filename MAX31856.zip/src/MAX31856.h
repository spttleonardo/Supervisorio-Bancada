#ifndef __MAX31856_H__
#define __MAX31856_H__

// Manual for library: http://lygte-info.dk/project/MAX31856Library%20UK.html
// This is version 1.00 from 2019-9-1
// By HKJ from lygte-info.dk

typedef enum {
  TC_B = 0x00,
  TC_E = 0x01,
  TC_J = 0x02,
  TC_K = 0x03,  // This is the default
  TC_N = 0x04,
  TC_R = 0x05,
  TC_S = 0x06,
  TC_T = 0x07,
  TC_G8 = 0x08,
  TC_G32 = 0x0c,
} MaxTCType;

const byte TC_FAULT_CJ_RANGE = 0x80;
const byte TC_FAULT_TC_RANGE = 0x40;
const byte TC_FAULT_CJ_HIGH = 0x20;
const byte TC_FAULT_CJ_LOW = 0x10;
const byte TC_FAULT_TC_HIGH = 0x08;
const byte TC_FAULT_TC_LOW = 0x04;
const byte TC_FAULT_VOLT = 0x02;
const byte TC_FAULT_OPEN = 0x01;

const byte TC_SAMPLES_1 = 0;
const byte TC_SAMPLES_2 = 1;
const byte TC_SAMPLES_4 = 2;
const byte TC_SAMPLES_8 = 3;
const byte TC_SAMPLES_16 = 4;


class MAX31856 {
  private:
    byte sdiPin;  // Data in to MAX31856, i.e. Arduino output
    byte sdoPin;  // Data out from MAX31856, i.e. Arduino input
    byte sckPin;
    byte csPin;
    byte drdyPin; // This pin is optional, 255=not used
    byte voltMultiplicationFactor = 0; // Factor for x8 and x32 mode, 0 in thermocoupler mode
    byte avg = 1;// Actual number of samples that is averaged, used to calculate time
    byte reg0;  // Copy of configuration register 0 to avoid reads when changing it
    byte reg1;  // Copy of configuration register 1 to avoid reads when changing it
    uint32_t doneTime;  // Time when conversion is ready in millis

    inline boolean isRunMode() {  // Continuous conversions?
      return reg0 & 0x80;
    }

    inline void writeReg0(byte val) {
      reg0 = val & ~0x42; // Mask out self clearing bits
      writeReg(0, val);
    }
    inline void writeReg1(byte val) {
      reg1 = val;
      writeReg(1, val);
    }

    byte readReg(byte reg);  // Read a register
    int16_t readReg2(byte reg);  // Read two registers with sign
    int32_t readReg3(byte reg);  // Read 3 registers with sign extension
    void writeReg(byte reg, byte val);
    byte spiXfer(byte v); // Bidir SPI transfer

  public:
    MAX31856(byte sdiPin, byte sdoPin, byte sckPin, byte csPin);
    MAX31856(byte sdiPin, byte sdoPin, byte sckPin, byte csPin, byte drdyPin);

    void begin();
    void setTCType(MaxTCType type);
    MaxTCType getTCType();
    inline boolean isVoltMode() {
      return voltMultiplicationFactor != 0;
    }

    byte getFault();
    void setFaultMask(byte mask);


    void setMainsFreq60Hz(boolean yes); // Use this before starting any conversions
    void setSamples(byte n);
    byte getSamples();
    uint16_t sampleTime();

    void start(); // Disable auto mode and run a single conversion
    boolean isReady();
    void setAuto();
    inline boolean isAuto() {
      return isRunMode();
    }

    void setCJRange(int8_t low, int8_t high);

    int8_t readCJRangeLow() {
      return (int8_t) readReg(4);
    }

    int8_t readCJRangeHigh() {
      return (int8_t) readReg(3);
    }

    void setCJOffset(float ofs);
    float getCJOffset();

    float readCJTemp();
    void setCJTemp(float temp);
    void setCJAuto(boolean yes = true);
    boolean isCJAuto();


    void setTCRange(float low, float high);
    float readTCRangeLow() {
      return readReg2(7) / 16.0;
    }

    float readTCRangeHigh() {
      return readReg2(5) / 16.0;
    }

    float readTCTemp(); // Read thermocoupler, wait for ready

    void serialPrintAllRegisters();
};












#endif
